package business;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import writers.ConcreteCsvWriterCreator;
import writers.ConcreteKonsoleWriterCreator;
import writers.WriterCreatorAydogan;
import writers.WriterProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseAusDatei(String typ) throws IOException{
		if("csv".equals(typ)){
			BufferedReader ein = new BufferedReader(new FileReader("Teesorte.csv"));
			String[] zeile = ein.readLine().split(";");
			this.teesorte = new Teesorte(Integer.parseInt(zeile[0]),
				zeile[1],
				zeile[2],
				zeile[3],
				zeile[4].split("_"));
			ein.close();
		}
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteCsvWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}

	public void schreibeTeesInKonsole() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteKonsoleWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}
}
