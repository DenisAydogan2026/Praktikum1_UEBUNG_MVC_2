package business;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import readers.ConcreteCsvReaderCreator;
import readers.ConcreteTxtReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteCsvReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod();
		this.teesorte = reader.leseTeesorte();
	}

	public void leseTeesorteAusTxtDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteTxtReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod();
		this.teesorte = reader.leseTeesorte();
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		BufferedWriter aus
			= new BufferedWriter(new FileWriter("TeesortenAusgabe.csv", true));
		aus.write(this.teesorte.gibTeesorteZurueck(';'));
		aus.close();
	}
}
