package business;

import java.io.IOException;

import readers.ConcreteReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;
import writers.ConcreteCsvWriterCreator;
import writers.WriterCreatorAydogan;
import writers.WriterProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod("csv");
		this.teesorte = reader.leseTeesorte();
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteCsvWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}

	public void leseTeesorteAusTxtDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod("txt");
		this.teesorte = reader.leseTeesorte();
	}
}
