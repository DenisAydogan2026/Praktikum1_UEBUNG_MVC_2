package writers;

// Rolle: ConcreteCreator - Variante B (ein Creator fuer alle Writer-Products)
public class ConcreteWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod(String typ) {
		if("csv".equals(typ)) {
			return new ConcreteCsvWriterProduct();
		}
		else {
			return new ConcreteKonsoleWriterProduct();
		}
	}
}
