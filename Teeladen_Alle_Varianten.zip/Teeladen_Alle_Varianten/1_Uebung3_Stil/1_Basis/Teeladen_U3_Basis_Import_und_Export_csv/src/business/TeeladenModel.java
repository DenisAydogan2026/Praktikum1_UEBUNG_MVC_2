package business;

import java.io.IOException;

import readers.ConcreteCsvReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;
import writers.ConcreteCsvWriterCreator;
import writers.WriterCreatorAydogan;
import writers.WriterProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteCsvReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod();
		this.teesorte = reader.leseTeesorte();
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteCsvWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}
}
