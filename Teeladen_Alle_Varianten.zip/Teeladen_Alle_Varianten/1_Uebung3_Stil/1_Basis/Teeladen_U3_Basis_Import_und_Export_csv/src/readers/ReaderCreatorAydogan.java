package readers;

// Rolle: Creator (abstrakt)
public abstract class ReaderCreatorAydogan {

	public abstract ReaderProductAydogan factoryMethod();
}
