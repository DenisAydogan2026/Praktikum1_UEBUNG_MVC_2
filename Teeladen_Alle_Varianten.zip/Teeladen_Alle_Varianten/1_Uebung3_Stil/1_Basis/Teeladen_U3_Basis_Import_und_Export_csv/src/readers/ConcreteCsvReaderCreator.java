package readers;

// Rolle: ConcreteCreator (Csv) - Variante A
public class ConcreteCsvReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod() {
		return new ConcreteCsvReaderProduct();
	}
}
