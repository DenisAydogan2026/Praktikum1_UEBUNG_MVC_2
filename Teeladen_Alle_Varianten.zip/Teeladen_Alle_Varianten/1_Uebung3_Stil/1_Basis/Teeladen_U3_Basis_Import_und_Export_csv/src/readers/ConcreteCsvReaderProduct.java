package readers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (csv)
public class ConcreteCsvReaderProduct extends ReaderProductAydogan {

	@Override
	public Teesorte leseTeesorte() throws IOException {
		BufferedReader ein = new BufferedReader(new FileReader("Teesorte.csv"));
		String[] zeile = ein.readLine().split(";");
		Teesorte teesorte = new Teesorte(Integer.parseInt(zeile[0]),
			zeile[1],
			zeile[2],
			zeile[3],
			zeile[4].split("_"));
		ein.close();
		return teesorte;
	}
}
