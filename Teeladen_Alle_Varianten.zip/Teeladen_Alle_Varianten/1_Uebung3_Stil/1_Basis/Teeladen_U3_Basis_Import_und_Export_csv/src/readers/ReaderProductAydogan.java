package readers;

import java.io.IOException;

import business.Teesorte;

// Rolle: Product (abstrakt)
public abstract class ReaderProductAydogan {

	public abstract Teesorte leseTeesorte() throws IOException;
}
