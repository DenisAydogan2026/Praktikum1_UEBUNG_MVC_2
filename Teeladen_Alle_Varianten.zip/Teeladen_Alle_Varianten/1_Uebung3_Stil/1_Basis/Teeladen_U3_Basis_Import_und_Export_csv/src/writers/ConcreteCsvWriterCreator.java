package writers;

// Rolle: ConcreteCreator (Csv) - Variante A
public class ConcreteCsvWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() {
		return new ConcreteCsvWriterProduct();
	}
}
