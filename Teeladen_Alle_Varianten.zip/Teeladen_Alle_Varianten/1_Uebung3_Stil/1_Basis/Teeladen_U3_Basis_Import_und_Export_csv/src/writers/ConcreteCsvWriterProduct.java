package writers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (csv)
public class ConcreteCsvWriterProduct extends WriterProductAydogan {

	@Override
	public void schreibeTeesorte(Teesorte teesorte) throws IOException {
		BufferedWriter aus
			= new BufferedWriter(new FileWriter("TeesortenAusgabe.csv", true));
		aus.write(teesorte.gibTeesorteZurueck(';'));
		aus.close();
	}
}
