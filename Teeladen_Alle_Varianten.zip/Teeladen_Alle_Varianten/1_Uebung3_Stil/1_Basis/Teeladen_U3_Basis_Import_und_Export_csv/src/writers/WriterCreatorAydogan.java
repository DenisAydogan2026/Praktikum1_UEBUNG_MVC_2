package writers;

// Rolle: Creator (abstrakt)
public abstract class WriterCreatorAydogan {

	public abstract WriterProductAydogan factoryMethod();
}
