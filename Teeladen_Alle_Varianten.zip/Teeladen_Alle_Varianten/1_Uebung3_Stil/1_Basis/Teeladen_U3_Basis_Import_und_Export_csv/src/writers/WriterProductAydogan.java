package writers;

import java.io.IOException;

import business.Teesorte;

// Rolle: Product (abstrakt)
public abstract class WriterProductAydogan {

	public abstract void schreibeTeesorte(Teesorte teesorte) throws IOException;
}
