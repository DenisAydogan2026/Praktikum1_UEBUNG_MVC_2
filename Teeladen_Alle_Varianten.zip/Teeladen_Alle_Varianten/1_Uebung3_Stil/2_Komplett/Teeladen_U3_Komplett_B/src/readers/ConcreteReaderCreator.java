package readers;

// Rolle: ConcreteCreator - Variante B (ein Creator fuer alle Reader-Products)
public class ConcreteReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod(String typ) {
		if("csv".equals(typ)) {
			return new ConcreteCsvReaderProduct();
		}
		else {
			return new ConcreteTxtReaderProduct();
		}
	}
}
