package writers;

// Rolle: ConcreteCreator - Variante B (ein Creator fuer alle Writer-Products)
public class ConcreteWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod(String typ) {
		if("csv".equals(typ)) {
			return new ConcreteCsvWriterProduct();
		}
		else if("txt".equals(typ)) {
			return new ConcreteTxtWriterProduct();
		}
		else {
			return new ConcreteKonsoleWriterProduct();
		}
	}
}
