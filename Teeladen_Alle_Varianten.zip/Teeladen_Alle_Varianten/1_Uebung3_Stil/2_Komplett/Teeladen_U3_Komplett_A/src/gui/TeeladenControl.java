package gui;

import java.io.IOException;

import business.TeeladenModel;
import business.Teesorte;
import javafx.stage.Stage;

public class TeeladenControl {

	private TeeladenModel teeladenModel;
	private TeeladenView teeladenView;

	public TeeladenControl(Stage primaryStage) {
		this.teeladenModel = new TeeladenModel();
		this.teeladenView = new TeeladenView(this, primaryStage, teeladenModel);
	}

	public void nehmeTeeAuf() {
		try {
			this.teeladenModel.setTeesorte(new Teesorte(
				Integer.parseInt(teeladenView.getTxtIdentnummer().getText()),
				teeladenView.getTxtBezeichnung().getText(),
				teeladenView.getTxtKategorie().getText(),
				teeladenView.getTxtMitKoffein().getText(),
				teeladenView.getTxtEnthalteneKraeuter().getText().split(";")));
			teeladenView.zeigeInformationsfensterAn("Die Teesorte wurde aufgenommen!");
		}
		catch(Exception exc){
			teeladenView.zeigeFehlermeldungsfensterAn(exc.getMessage());
		}
	}

	// GEAENDERT: typ waehlt die Model-Methode, txt ist jetzt implementiert
	public void leseAusDatei(String typ){
		try {
			if("csv".equals(typ)){
				teeladenModel.leseTeesorteAusCsvDatei();
			}
			else{
				teeladenModel.leseTeesorteAusTxtDatei();
			}
			teeladenView.zeigeInformationsfensterAn(
				"Die Teesorte wurde gelesen!");
		}
		catch(IOException exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"IOException beim Lesen!");
		}
		catch(Exception exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"Unbekannter Fehler beim Lesen!");
		}
	}

	public void schreibeTeesInCsvDatei() {
		try {
			teeladenModel.schreibeTeesInCsvDatei();
			teeladenView.zeigeInformationsfensterAn(
				"Die Teesorten wurden gespeichert!");
		}
		catch(IOException exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"IOException beim Speichern!");
		}
		catch(Exception exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"Unbekannter Fehler beim Speichern!");
		}
	}

	// NEU
	public void schreibeTeesInTxtDatei() {
		try {
			teeladenModel.schreibeTeesInTxtDatei();
			teeladenView.zeigeInformationsfensterAn(
				"Die Teesorten wurden gespeichert!");
		}
		catch(IOException exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"IOException beim Speichern!");
		}
		catch(Exception exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"Unbekannter Fehler beim Speichern!");
		}
	}

	// NEU
	public void schreibeTeesInKonsole() {
		try {
			teeladenModel.schreibeTeesInKonsole();
			teeladenView.zeigeInformationsfensterAn(
				"Die Teesorten wurden in der Konsole ausgegeben!");
		}
		catch(IOException exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"IOException beim Ausgeben!");
		}
		catch(Exception exc){
			teeladenView.zeigeFehlermeldungsfensterAn(
				"Unbekannter Fehler beim Ausgeben!");
		}
	}
}
