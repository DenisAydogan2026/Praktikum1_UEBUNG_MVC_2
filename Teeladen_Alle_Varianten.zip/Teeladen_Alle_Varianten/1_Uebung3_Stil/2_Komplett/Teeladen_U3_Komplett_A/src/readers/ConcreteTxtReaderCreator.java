package readers;

// Rolle: ConcreteCreator (Txt) - Variante A
public class ConcreteTxtReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod() {
		return new ConcreteTxtReaderProduct();
	}
}
