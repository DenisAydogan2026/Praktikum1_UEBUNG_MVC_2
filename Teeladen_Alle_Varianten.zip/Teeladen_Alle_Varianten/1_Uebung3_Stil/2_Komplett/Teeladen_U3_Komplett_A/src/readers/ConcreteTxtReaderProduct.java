package readers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (txt)
public class ConcreteTxtReaderProduct extends ReaderProductAydogan {

	@Override
	public Teesorte leseTeesorte() throws IOException {
		BufferedReader ein = new BufferedReader(new FileReader("Teesorte.txt"));
		int identnummer = Integer.parseInt(ein.readLine());
		String bezeichnung = ein.readLine();
		String kategorie = ein.readLine();
		String mitKoffein = ein.readLine();
		String[] kraeuter = ein.readLine().split("_");
		Teesorte teesorte = new Teesorte(identnummer,
			bezeichnung,
			kategorie,
			mitKoffein,
			kraeuter);
		ein.close();
		return teesorte;
	}
}
