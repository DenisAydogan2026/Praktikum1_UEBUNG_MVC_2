package writers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (txt)
public class ConcreteTxtWriterProduct extends WriterProductAydogan {

	@Override
	public void schreibeTeesorte(Teesorte teesorte) throws IOException {
		BufferedWriter aus
			= new BufferedWriter(new FileWriter("TeesortenAusgabe.txt"));
		aus.write(teesorte.getIdentnummer() + "");
		aus.newLine();
		aus.write(teesorte.getBezeichnung());
		aus.newLine();
		aus.write(teesorte.getKategorie());
		aus.newLine();
		aus.write(teesorte.getMitKoffein());
		aus.newLine();
		aus.write(teesorte.getEnthalteneKraeuterAlsString('_'));
		aus.newLine();
		aus.close();
	}
}
