package writers;

// Rolle: ConcreteCreator (Konsole) - Variante A
public class ConcreteKonsoleWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() {
		return new ConcreteKonsoleWriterProduct();
	}
}
