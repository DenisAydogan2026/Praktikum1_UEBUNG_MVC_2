package writers;

// Rolle: ConcreteCreator (Txt) - Variante A
public class ConcreteTxtWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() {
		return new ConcreteTxtWriterProduct();
	}
}
