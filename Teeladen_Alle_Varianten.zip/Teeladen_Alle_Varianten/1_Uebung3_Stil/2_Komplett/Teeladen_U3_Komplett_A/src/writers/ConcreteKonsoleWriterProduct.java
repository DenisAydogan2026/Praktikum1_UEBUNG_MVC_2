package writers;

import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (Konsole)
public class ConcreteKonsoleWriterProduct extends WriterProductAydogan {

	@Override
	public void schreibeTeesorte(Teesorte teesorte) throws IOException {
		System.out.println("Identnummer: " + teesorte.getIdentnummer());
		System.out.println("Bezeichnung: " + teesorte.getBezeichnung());
		System.out.println("Kategorie:   " + teesorte.getKategorie());
		System.out.println("Mit Koffein: " + teesorte.getMitKoffein());
		System.out.println("Kraeuter:    " + teesorte.getEnthalteneKraeuterAlsString(','));
		System.out.println("");
	}
}
