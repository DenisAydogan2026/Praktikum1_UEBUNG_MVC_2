package business;

import java.io.IOException;

import readers.ConcreteCsvReaderCreator;
import readers.ConcreteTxtReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;
import writers.ConcreteCsvWriterCreator;
import writers.ConcreteKonsoleWriterCreator;
import writers.ConcreteTxtWriterCreator;
import writers.WriterCreatorAydogan;
import writers.WriterProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteCsvReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod();
		this.teesorte = reader.leseTeesorte();
	}

	public void leseTeesorteAusTxtDatei() throws IOException {
		ReaderCreatorAydogan readerCreator = new ConcreteTxtReaderCreator();
		ReaderProductAydogan reader = readerCreator.factoryMethod();
		this.teesorte = reader.leseTeesorte();
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteCsvWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}

	public void schreibeTeesInTxtDatei() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteTxtWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}

	public void schreibeTeesInKonsole() throws IOException {
		WriterCreatorAydogan writerCreator = new ConcreteKonsoleWriterCreator();
		WriterProductAydogan writer = writerCreator.factoryMethod();
		writer.schreibeTeesorte(this.teesorte);
	}
}
