package readers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

// Rolle: ConcreteProduct (txt)
public class ConcreteTxtReaderProduct extends ReaderProductAydogan {

	private BufferedReader ein;

	// BufferedReader wird im Konstruktor initialisiert
	public ConcreteTxtReaderProduct() throws IOException {
		this.ein = new BufferedReader(new FileReader("Teesorte.txt"));
	}

	// 5 Zeilen lesen, jede Zeile = ein Wert
	@Override
	public String[] leseAusDatei() throws IOException {
		String[] ergebnisZeile = new String[5];
		String zeile = this.ein.readLine();
		int i = 0;
		while(i < ergebnisZeile.length) {
			ergebnisZeile[i] = zeile;
			zeile = this.ein.readLine();
			i++;
		}
		return ergebnisZeile;
	}

	@Override
	public void schliesseDatei() throws IOException {
		this.ein.close();
	}
}
