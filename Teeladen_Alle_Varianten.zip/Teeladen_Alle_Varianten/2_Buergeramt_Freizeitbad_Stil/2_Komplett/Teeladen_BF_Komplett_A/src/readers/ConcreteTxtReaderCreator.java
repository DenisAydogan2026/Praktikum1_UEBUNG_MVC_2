package readers;

import java.io.IOException;

// Rolle: ConcreteCreator (txt)
public class ConcreteTxtReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod() throws IOException {
		return new ConcreteTxtReaderProduct();
	}
}
