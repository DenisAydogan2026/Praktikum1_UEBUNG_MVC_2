package writers;

import java.io.IOException;

// Rolle: ConcreteCreator (txt)
public class ConcreteTxtWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() throws IOException {
		return new ConcreteTxtWriterProduct();
	}
}
