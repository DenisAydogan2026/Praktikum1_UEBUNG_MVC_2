package writers;

import java.io.IOException;

// Rolle: ConcreteCreator (konsole)
public class ConcreteKonsoleWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() throws IOException {
		return new ConcreteKonsoleWriterProduct();
	}
}
