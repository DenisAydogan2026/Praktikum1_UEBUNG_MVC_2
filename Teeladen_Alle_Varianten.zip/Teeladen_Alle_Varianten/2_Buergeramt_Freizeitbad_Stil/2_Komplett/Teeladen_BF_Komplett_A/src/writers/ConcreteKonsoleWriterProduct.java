package writers;

import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (Konsole)
public class ConcreteKonsoleWriterProduct extends WriterProductAydogan {

	@Override
	public void fuegeInDateiHinzu(Object object) throws IOException {
		Teesorte teesorte = (Teesorte) object;
		System.out.println("Daten der Teesorte");
		System.out.println("Identnummer der Teesorte:          " + teesorte.getIdentnummer());
		System.out.println("Bezeichnung der Teesorte:          " + teesorte.getBezeichnung());
		System.out.println("Kategorie der Teesorte:            " + teesorte.getKategorie());
		System.out.println("Mit Koffein:                       " + teesorte.getMitKoffein());
		System.out.println("Enthaltene Kraeuter der Teesorte:  " + teesorte.getEnthalteneKraeuterAlsString(','));
	}

	@Override
	public void schliesseDatei() throws IOException {
		// leer: die Konsole wird nicht geschlossen
	}
}
