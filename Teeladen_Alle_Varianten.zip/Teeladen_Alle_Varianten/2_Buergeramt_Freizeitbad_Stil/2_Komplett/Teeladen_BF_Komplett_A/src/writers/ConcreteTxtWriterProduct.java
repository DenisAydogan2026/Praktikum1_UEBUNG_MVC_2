package writers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (txt)
public class ConcreteTxtWriterProduct extends WriterProductAydogan {

	private BufferedWriter writer;

	// BufferedWriter wird im Konstruktor initialisiert
	public ConcreteTxtWriterProduct() throws IOException {
		this.writer = new BufferedWriter(new FileWriter("TeesortenAusgabe.txt"));
	}

	@Override
	public void fuegeInDateiHinzu(Object object) throws IOException {
		Teesorte teesorte = (Teesorte) object;
		this.writer.write("Daten der Teesorte");
		this.writer.newLine();
		this.writer.write("Identnummer der Teesorte:          " + teesorte.getIdentnummer());
		this.writer.newLine();
		this.writer.write("Bezeichnung der Teesorte:          " + teesorte.getBezeichnung());
		this.writer.newLine();
		this.writer.write("Kategorie der Teesorte:            " + teesorte.getKategorie());
		this.writer.newLine();
		this.writer.write("Mit Koffein:                       " + teesorte.getMitKoffein());
		this.writer.newLine();
		this.writer.write("Enthaltene Kraeuter der Teesorte:  " + teesorte.getEnthalteneKraeuterAlsString(','));
		this.writer.newLine();
	}

	@Override
	public void schliesseDatei() throws IOException {
		this.writer.close();
	}
}
