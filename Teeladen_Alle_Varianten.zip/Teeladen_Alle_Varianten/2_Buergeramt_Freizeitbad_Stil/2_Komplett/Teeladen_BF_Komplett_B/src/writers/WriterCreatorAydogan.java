package writers;

import java.io.IOException;

// Rolle: Creator (abstrakt)
public abstract class WriterCreatorAydogan {

	public abstract WriterProductAydogan factoryMethod(String typ) throws IOException;
}
