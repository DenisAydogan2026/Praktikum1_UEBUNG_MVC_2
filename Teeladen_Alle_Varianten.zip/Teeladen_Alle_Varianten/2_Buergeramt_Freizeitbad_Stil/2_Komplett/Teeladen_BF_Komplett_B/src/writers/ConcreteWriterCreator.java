package writers;

import java.io.IOException;

// Rolle: ConcreteCreatorAB - Variante B
public class ConcreteWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod(String typ) throws IOException {
		if("csv".equals(typ)) {
			return new ConcreteCsvWriterProduct();
		}
		else if("txt".equals(typ)) {
			return new ConcreteTxtWriterProduct();
		}
		else {
			return new ConcreteKonsoleWriterProduct();
		}
	}
}
