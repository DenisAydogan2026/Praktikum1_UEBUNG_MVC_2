package readers;

import java.io.IOException;

// Rolle: ConcreteCreatorAB - Variante B
public class ConcreteReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod(String typ) throws IOException {
		if("csv".equals(typ)) {
			return new ConcreteCsvReaderProduct();
		}
		else {
			return new ConcreteTxtReaderProduct();
		}
	}
}
