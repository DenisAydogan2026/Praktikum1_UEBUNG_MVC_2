package readers;

import java.io.IOException;

// Rolle: Creator (abstrakt)
public abstract class ReaderCreatorAydogan {

	public abstract ReaderProductAydogan factoryMethod(String typ) throws IOException;
}
