package business;

import java.io.IOException;

import readers.ConcreteCsvReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;
import writers.ConcreteCsvWriterCreator;
import writers.ConcreteKonsoleWriterCreator;
import writers.ConcreteTxtWriterCreator;
import writers.WriterCreatorAydogan;
import writers.WriterProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		ReaderCreatorAydogan creator = new ConcreteCsvReaderCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		ReaderProductAydogan reader = creator.factoryMethod();

		String[] zeile = reader.leseAusDatei();
		this.teesorte = new Teesorte(Integer.parseInt(zeile[0]),
			zeile[1],
			zeile[2],
			zeile[3],
			zeile[4].split("_"));
		reader.schliesseDatei();
	}

	public void schreibeTeesInCsvDatei()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		WriterCreatorAydogan creator = new ConcreteCsvWriterCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		WriterProductAydogan writer = creator.factoryMethod();

		writer.fuegeInDateiHinzu(this.teesorte);
		writer.schliesseDatei();
	}

	public void schreibeTeesInTxtDatei()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		WriterCreatorAydogan creator = new ConcreteTxtWriterCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		WriterProductAydogan writer = creator.factoryMethod();

		writer.fuegeInDateiHinzu(this.teesorte);
		writer.schliesseDatei();
	}

	public void schreibeTeesInKonsole()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		WriterCreatorAydogan creator = new ConcreteKonsoleWriterCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		WriterProductAydogan writer = creator.factoryMethod();

		writer.fuegeInDateiHinzu(this.teesorte);
		writer.schliesseDatei();
	}
}
