package business;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import readers.ConcreteCsvReaderCreator;
import readers.ConcreteTxtReaderCreator;
import readers.ReaderCreatorAydogan;
import readers.ReaderProductAydogan;

public class TeeladenModel {

	private Teesorte teesorte;

	public Teesorte getTeesorte() {
		return teesorte;
	}

	public void setTeesorte(Teesorte teesorte) {
		this.teesorte = teesorte;
	}

	public void leseTeesorteAusCsvDatei()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		ReaderCreatorAydogan creator = new ConcreteCsvReaderCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		ReaderProductAydogan reader = creator.factoryMethod();

		String[] zeile = reader.leseAusDatei();
		this.teesorte = new Teesorte(Integer.parseInt(zeile[0]),
			zeile[1],
			zeile[2],
			zeile[3],
			zeile[4].split("_"));
		reader.schliesseDatei();
	}

	public void leseTeesorteAusTxtDatei()
		throws IOException{
		// Kreieren eines Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Creator-Klasse.
		ReaderCreatorAydogan creator = new ConcreteTxtReaderCreator();

		// Kreieren eines Product-Objekts mit Hilfe der Factory-
		// Methode des Creator-Objekts und Abspeicherung mit Hilfe
		// einer Variablen vom Typ der entsprechenden abstrakten
		// Product-Klasse.
		ReaderProductAydogan reader = creator.factoryMethod();

		String[] zeile = reader.leseAusDatei();
		this.teesorte = new Teesorte(Integer.parseInt(zeile[0]),
			zeile[1],
			zeile[2],
			zeile[3],
			zeile[4].split("_"));
		reader.schliesseDatei();
	}

	public void schreibeTeesInCsvDatei() throws IOException {
		BufferedWriter aus
			= new BufferedWriter(new FileWriter("TeesortenAusgabe.csv", true));
		aus.write(this.teesorte.gibTeesorteZurueck(';'));
		aus.close();
	}
}
