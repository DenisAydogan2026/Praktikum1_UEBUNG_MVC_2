package readers;

import java.io.IOException;

// Rolle: ConcreteCreator (csv)
public class ConcreteCsvReaderCreator extends ReaderCreatorAydogan {

	@Override
	public ReaderProductAydogan factoryMethod() throws IOException {
		return new ConcreteCsvReaderProduct();
	}
}
