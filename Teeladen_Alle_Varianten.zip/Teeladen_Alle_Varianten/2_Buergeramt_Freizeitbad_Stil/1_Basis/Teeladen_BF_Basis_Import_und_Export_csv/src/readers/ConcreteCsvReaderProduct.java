package readers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

// Rolle: ConcreteProduct (csv)
public class ConcreteCsvReaderProduct extends ReaderProductAydogan {

	private BufferedReader ein;

	// BufferedReader wird im Konstruktor initialisiert
	public ConcreteCsvReaderProduct() throws IOException {
		this.ein = new BufferedReader(new FileReader("Teesorte.csv"));
	}

	@Override
	public String[] leseAusDatei() throws IOException {
		String[] zeile = this.ein.readLine().split(";");
		return zeile;
	}

	@Override
	public void schliesseDatei() throws IOException {
		this.ein.close();
	}
}
