package readers;

import java.io.IOException;

// Rolle: Product (abstrakt)
public abstract class ReaderProductAydogan {

	public abstract String[] leseAusDatei() throws IOException;

	public abstract void schliesseDatei() throws IOException;
}
