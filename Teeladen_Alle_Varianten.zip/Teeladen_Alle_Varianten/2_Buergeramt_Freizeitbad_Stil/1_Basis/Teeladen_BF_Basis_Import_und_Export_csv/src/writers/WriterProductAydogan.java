package writers;

import java.io.IOException;

// Rolle: Product (abstrakt)
public abstract class WriterProductAydogan {

	public abstract void fuegeInDateiHinzu(Object object) throws IOException;

	public abstract void schliesseDatei() throws IOException;
}
