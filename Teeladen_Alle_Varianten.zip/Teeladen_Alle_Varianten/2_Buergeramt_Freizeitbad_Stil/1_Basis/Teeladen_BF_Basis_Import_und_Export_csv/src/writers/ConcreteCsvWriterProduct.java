package writers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import business.Teesorte;

// Rolle: ConcreteProduct (csv)
public class ConcreteCsvWriterProduct extends WriterProductAydogan {

	private BufferedWriter writer;

	// BufferedWriter wird im Konstruktor initialisiert (true = anhaengen)
	public ConcreteCsvWriterProduct() throws IOException {
		this.writer = new BufferedWriter(new FileWriter("TeesortenAusgabe.csv", true));
	}

	@Override
	public void fuegeInDateiHinzu(Object object) throws IOException {
		// Object -> Teesorte (Cast), damit die Teesorte-Methoden verfuegbar sind
		Teesorte teesorte = (Teesorte) object;
		this.writer.write(teesorte.gibTeesorteZurueck(';'));
	}

	@Override
	public void schliesseDatei() throws IOException {
		this.writer.close();
	}
}
