package writers;

import java.io.IOException;

// Rolle: ConcreteCreator (csv)
public class ConcreteCsvWriterCreator extends WriterCreatorAydogan {

	@Override
	public WriterProductAydogan factoryMethod() throws IOException {
		return new ConcreteCsvWriterProduct();
	}
}
